# display_rows.handlebars

{{#each rows}}
<li>
<span class="icon">
<a target="_blank" href="{{target}}" data-doc-id="{{docid}}" data-popup="{{popup}}" class="btn btn-neutral">
<img src="{{icon}}" />
</a>
</span>
<div class="info">
<h2 class="title">{{title}}</h2>{{#if author}}
<p class="small">{{ author }}</p>{{/if}}{{#if description}}
<p class="desc">{{description}}</p>{{/if}}
</div>
</li>
{{/each}}
