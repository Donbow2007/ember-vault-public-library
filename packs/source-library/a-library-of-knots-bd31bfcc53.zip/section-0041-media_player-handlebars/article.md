# media_player.handlebars

{{#each doc.items}}
<p><a target="_blank" href="{{this.fpath}}"><img class="icon" src="{{this.icon}}" /> {{this.fname}}</a>
{{#if this.is_file}}{{else}}
<{{kind}} class="video-js vjs-default-skin nautilus-{{kind}}">
<source src="{{this.fpath}}" type="{{this.mime}}" /></{{kind}}>
{{/if}}
</p>
{{/each}}
