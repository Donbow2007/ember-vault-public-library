# Who can and cannot take empagliflozin - NHS

Who can and cannot take empagliflozin - Brand name: Jardiance Who can take empagliflozin Most adults aged 18 years and older can take empagliflozin. Check with a doctor if you're aged 75 years or older. Some medicines containing empagliflozin are not recommended for older people. It is not used for treating type 1 diabetes . Who may not be able to take empagliflozin Empagliflozin is not suitable for some people. To make sure it's safe for you, tell your doctor before starting to take this medicine if you: have ever had an allergic reaction to empagliflozin or any other medicine have high blood sugar (glucose) and ketones (produced when your body breaks down fat) in your pee – there are home tests for this have severe kidney or liver disease have low blood pressure often get urinary tract infections (UTIs) are due to have surgery are pregnant, trying to get pregnant or breastfeeding
Page last reviewed: 2 February 2023

Next review due: 2 February 2026
Help us improve our website Can you answer a 5 minute survey about your visit today? Take our survey
