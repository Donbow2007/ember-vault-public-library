# Tag: raw

Steak Tartare
