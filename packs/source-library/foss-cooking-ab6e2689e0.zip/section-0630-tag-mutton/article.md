# Tag: mutton

Lamb Biriyani
