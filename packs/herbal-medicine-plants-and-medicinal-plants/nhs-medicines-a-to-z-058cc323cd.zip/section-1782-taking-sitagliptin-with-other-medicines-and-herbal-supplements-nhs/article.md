# Taking sitagliptin with other medicines and herbal supplements - NHS

Taking sitagliptin with other medicines and herbal supplements

Cautions with other medicines Some medicines and sitagliptin can affect each other. Taking them at the same time as sitagliptin can cause low blood sugar or increase your risk of getting side effects. Tell your doctor or pharmacist if you're taking: insulin or any other diabetes medicine – your doctor may want to lower the dose of these medicines when you start sitagliptin to reduce the risk of low blood sugar (hypoglycaemia) ketoconazole or itraconazole, medicines for fungal infections ritonavir, a medicine used to treat HIV and AIDS clarithromycin , an antibiotic for treating pneumonia and ear infections digoxin , a medicine for heart conditions, including heart failure Make sure that your doctor and pharmacist know you're taking sitagliptin before starting or stopping any other medicine. Mixing sitagliptin with herbal remedies and supplements There's very little information about taking herbal remedies and supplements with sitagliptin. However, taking them at the same time as sitagliptin can cause low blood sugar . Important:
Medicine safety
Tell your doctor or pharmacist if you're taking any other medicines, including herbal remedies, vitamins or supplements.
Page last reviewed: 11 February 2022

Next review due: 11 February 2025
Help us improve our website Can you answer a 5 minute survey about your visit today? Take our survey
