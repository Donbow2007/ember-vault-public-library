# Taking metformin with other medicines and herbal supplements - NHS

Taking metformin with other medicines and herbal supplements

Cautions with other medicines There are some medicines that can affect the way metformin works. If you're taking any of the following medicines, your blood sugar levels may need to be checked more often and your dose changed: steroid tablets, such as prednisolone tablets that make you pee more (diuretics), such as furosemide medicines to treat heart problems and high blood pressure (hypertension) male and female hormones, such as testosterone, oestrogen or progesterone other diabetes medicines Your doctor may need to make a small change to your metformin dose if you have just started taking contraceptive pills. This is because contraceptive pills can change how your body handles sugar. Mixing metformin with herbal remedies and supplements There's not enough information to say that complementary medicines and herbal remedies are safe to take with metformin. They're not tested in the same way as pharmacy and prescription medicines. They're generally not tested for the effect they have on other medicines. Important:
Medicine safety
Tell your doctor or pharmacist if you're taking any other medicines, including herbal remedies, vitamins or supplements.
Page last reviewed: 24 March 2022

Next review due: 24 March 2025
Help us improve our website Can you answer a 5 minute survey about your visit today? Take our survey
