# Taking gliclazide with other medicines and herbal supplements - NHS

Taking gliclazide with other medicines and herbal supplements

Cautions with other medicines There are some medicines that affect the way gliclazide works. Taking them at the same time as gliclazide can cause low blood sugar. Tell your doctor if you're taking any of these medicines: steroid tablets, such as prednisolone some medicines used to treat heart problems and high blood pressure medicines to treat bacterial or fungal infections, such as clarithromycin or fluconazole painkillers – non-steroidal anti-inflammatory drugs ( NSAIDs ) such as ibuprofen or aspirin medicines used to treat asthma, such as salbutamol male and female hormones, such as testosterone, oestrogen or progesterone other diabetes medicines medicines that help to prevent blood clots, such as warfarin You might need a small adjustment in your gliclazide dose after starting contraceptive pills. In rare cases, they can increase blood sugar levels. Taking gliclazide with painkillers It's safe to take paracetamol with gliclazide. Talk to your pharmacist or doctor before taking NSAIDs such as aspirin or ibuprofen . These painkillers can affect gliclazide and lower your blood sugar levels too much. Mixing gliclazide with herbal remedies and supplements Do not take the herbal remedy St John's wort (sometimes taken for depression). It may change the way your body processes gliclazide. There's not enough information to say that other herbal remedies and supplements are safe to take with gliclazide. However, taking them at the same time as gliclazide can cause low blood sugar . Herbal remedies and supplements are not tested in the same way as pharmacy and prescription medicines. They're generally not tested for the effect they have on other medicines. Important:
Medicine safety
Tell your doctor or pharmacist if you're taking any other medicines, including herbal remedies, vitamins or supplements.
Page last reviewed: 24 March 2022

Next review due: 24 March 2025
Help us improve our website Can you answer a 5 minute survey about your visit today? Take our survey
