# Easy Chicken and Rice Casserole

⏲️ Prep time: 5 min 🍳 Cook time: 40 min 🍽️ Servings: 4 Ingredients 1/2 cup Onion, chopped 1/2 cup Celery, chopped 2 Tbsp Butter or margarine 2 cups Chicken, cooked and chopped 1 3/4 cups Hot water 2/3 cup Long Grain White Rice 1 can (10 oz) Mushrooms with liquid 1 cup Frozen Peas and Carrots 1 tsp Dried Thyme and Rosemary Directions In large fry pan, cook onion and celery in butter until soft. Stir in remaining ingredients. Bake in covered 8 cup baking dish in preheated (350F) oven for about 30 minutes or until rice is cooked.
