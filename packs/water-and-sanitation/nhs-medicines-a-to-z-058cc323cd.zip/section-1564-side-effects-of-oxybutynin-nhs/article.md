# Side effects of oxybutynin - NHS

Side effects of oxybutynin - Brand names: Aspire, Ditropan, Kentera Like all medicines, oxybutynin can cause side effects, but not everyone gets them. Common side effects of oxybutynin These common side effects of oxybutynin may affect more than 1 in 100 people. There are things you can do to help cope with them:
Dry mouth
Try sugar-free gum or sucking sugar-free sweets. Having a dry mouth can cause tooth decay or a fungal infection. It also might stop medicine that you put under your tongue from dissolving properly, such as medicine for angina .
Headache
Make sure you rest and drink plenty of fluids. Avoid alcohol. Ask your pharmacist to recommend a painkiller. Talk to your doctor if your headache is severe or does not get better.
Feeling dizzy, sleepy, or a spinning sensation (vertigo)
Do not drive, cycle, use tools, or operate machinery. Avoid drinking alcohol, as this may make your symptoms worse.
Diarrhoea
Drink lots of fluids, such as water or squash, to avoid dehydration . Signs of dehydration include peeing less than usual or having dark, strong-smelling pee. Do not take any other medicines to treat diarrhoea without speaking to a pharmacist or doctor. If you take the combined pill or progestogen-only pill and you have severe diarrhoea for more than 24 hours, your contraception may not protect you from pregnancy. Check the pill packet for advice. Speak to a pharmacist or doctor if diarrhoea lasts more than 1 or 2 days.
Being sick (vomiting)
Try small frequent sips of water to avoid dehydration . Signs of dehydration include peeing less than usual or having dark, strong-smelling pee. If you take the combined pill or progestogen-only pill and you're being sick, your contraception may not protect you from pregnancy. Check the pill packet for advice. Speak to a pharmacist or doctor if vomiting lasts more than 1 or 2 days.
Constipation
Get more fibre into your diet , such as fresh fruit, vegetables and cereals, and drink plenty of water. Try to exercise more regularly, for example, by going for a daily walk or run.
Farting and burping (wind)
Eat less foods that cause wind, like lentils, peas, beans and onions. It might also help to eat smaller and more frequent meals, eat and drink slowly, and exercise regularly. Ask your pharmacist about remedies you can buy to help with trapped wind.
Stomach pain
Try to rest and relax. It can help to eat and drink slowly and have smaller and more frequent meals. Putting a heat pad or a covered hot water bottle on your stomach may also help. If you're in a lot of sudden, severe pain, speak to your pharmacist or doctor.
Dry eyes
Ask your pharmacist or optician to recommend some eye drops for dry eyes . If you wear contact lenses and these become uncomfortable, you might prefer to wear glasses instead while you're taking oxybutynin.
Blurred vision
Do not drive or cycle until you can see clearly again. Do not take your next dose of oxybutynin if your vision is still blurred. Speak to your doctor or pharmacist if your vision has not returned to normal a day after taking your last dose.
Problems or pain when peeing, and not being able to empty your bladder
Try to relax when you pee. Do not try to force the flow of pee. If it does not happen, try again later. Talk to a doctor urgently if you cannot pee at all. Talk to your doctor or pharmacist if the advice on how to cope does not help and a side effect is still bothering you or does not go away. Serious side effects Serious side effects are rare. Tell your doctor or call 111 straight away if you have: stomach pain (especially after meals), feeling sick or being sick, a long-lasting urge to poo, not being able to poo or you have runny poos – these are all signs of pseudo-obstruction where large, hardened poo gets stuck and you cannot push it out difficulty fully emptying your bladder, or difficulty in starting to pee – these are signs of urinary retention, where pee builds up in your bladder because you're unable to pee a high temperature or chills, a burning feeling when peeing, pain in your back or side, or bloody or cloudy pee – these can be signs of a severe urinary tract infection (UTI) swollen ankles or legs (oedema) – where fluid builds up in your legs Immediate action required: Call 999 now if:
you feel you're overheating and are not sweating normally when you're somewhere hot or when you have a high temperature Serious allergic reaction In rare cases, it's possible to have a serious allergic reaction ( anaphylaxis ) to oxybutynin. Immediate action required: Call 999 now if:
your lips, mouth, throat or tongue suddenly become swollen you're breathing very fast or struggling to breathe (you may become very wheezy or feel like you're choking or gasping for air) your throat feels tight or you're struggling to swallow your skin, tongue or lips turn blue, grey or pale (if you have black or brown skin, this may be easier to see on the palms of your hands or soles of your feet) you suddenly become very confused, drowsy or dizzy someone faints and cannot be woken up a child is limp, floppy or not responding like they normally do (their head may fall to the side, backwards or forwards, or they may find it difficult to lift their head or focus on your face) You or the person who's unwell may also have a rash that's swollen, raised, itchy, blistered or peeling. These can be signs of a serious allergic reaction and may need immediate treatment in hospital. Information: Do not drive yourself to A&E. The person you speak to at 999 will give you advice about what to do. Other side effects These are not all the side effects of oxybutynin. For a full list, see the leaflet inside your medicines packet. Information: Reporting side effects You can report any suspected side effect using the Yellow Card safety scheme. Visit the Yellow Card website for more information about reporting side effects .
Page last reviewed: 16 August 2024

Next review due: 16 August 2027
Help us improve our website Can you answer a 5 minute survey about your visit today? Take our survey
