# Ham and Lentil Soup

For more flavour, boil down a soup bone and use the broth when filling the crock pot. ⏲️ Prep time: 5 min 🍳 Cook time: 8 hour 🍽️ Servings: 6 Ingredients 2 cup Lentils 1/2 lb Ham, diced 1 Onion, chopped 1 Bay leaf 2 ribs Celery, chopped 1 clove Garlic, minced Directions Combine all ingredients with 2 quarts water in the Crock Pot. Cook on low, covered, 8 to 10 hours. Adjust seasonings and serve.
