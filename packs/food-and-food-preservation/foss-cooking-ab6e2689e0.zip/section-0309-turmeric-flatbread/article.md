# Turmeric Flatbread

A great companion to Turkish Red Lentil Soup. ⏲️ Prep time: 20 min 🍳 Cook time: 10 min 🍽️ Servings: 4 Ingredients 1 cup Wheat Flour (white or whole) 1/2 Tbsp Ground Turmeric 1/2 tsp Kosher Salt 1/4 tsp Baking Powder 2 Tbsp Olive Oil Directions Combine flour, turmeric, salt and baking powder. Stir in 1/3 cup water and the olive oil. Knead until smooth (1-2 min). Cover and set aside 15 minutes. Cut the dough into 4 pieces; flatten each into a 6-inch round. Cook one at a time in an oiled skillet over medium-high heat, flip when browned (2 mins).
